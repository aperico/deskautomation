

static const struct id3_frametype wordlist[] =
{
  {0, "Encryption method registration"},
  {1, "Popularimeter"},
};



#line 3 "<stdout>"
typedef int8_t flex_int8_t;
